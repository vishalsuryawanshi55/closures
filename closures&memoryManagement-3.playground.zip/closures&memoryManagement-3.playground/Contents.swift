//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Declaring a closure
//{(parameters)->return type in
//statements.Closures can use in out parameters but one can nt assign default values to any parameter
//}
//a closure that does not accept parameter and return string
var hello:()->(String)={
    return "Hello!"
}
let h  = hello()
print(h)

//a closure that take one int and returns an Int
var double:(Int)->(Int)={
    x in return 2*x
}
var d = double(2)
print(d)

var alsoDouble=double
d = alsoDouble(3)
print(d)

var noParmAndNoReturnVal:()->() =
{
    print("Hello");
    
}
noParmAndNoReturnVal()


var noParamButReturns:()->(Int) =
{
    return 1000;
}
let n = noParamButReturns()
print(n)

var oneParamAndReturn:(Int)->(Int) =
{
    x in return x%10
}


var multiParm:(String,String)->(String) =
{
    (first,secod)->String in
    return first+" "+secod
    
}
//Capturing values.
//A closure can capture values
var number = 0
var addOne =
{
    number+=1
}
var printNumber =
{
    print(number)
}
//Closure can capture variables those are not global
func makeIterator(from start:Int,step:Int) ->()->Int
{
    var i = start
    return
        {
          let currentVal = i
            i += step
            return currentVal
    }
}
var iterator = makeIterator(from: 1, step: 1)
iterator()
iterator()
iterator()
var anotherIteraor = makeIterator(from: 1, step: 3)
//Trailing Closure Syntax
//If the last parameter of a function is closure then you can write it after function call

func sum(from: Int, to: Int, f: (Int) -> (Int)) -> Int {
    var sum = 0
    for i in from...to {
        sum += f(i)
    }
    return sum
}
sum(from: 1, to: 10)
{
    
     $0 * $0
}


//sum(from: 1, to: 10) {
   // $0
//} // the sum of the first 10 numbers

sum(from: 1, to: 10) {
    $0 * $0
} // the sum of the first 10 squares


//Closures are reference type
//Higher order functions :which takes function as input and outputs a function
//there are three higher order functions
//Map
//Map transforms an array using function
//Filter
//Filter selects the elemets of an array which satisfies certain condition
//Reduce combines all the valus from array into single value
//Escaping Closures

/* @nonescaping closures:
 When you are passing a closure in function’s arguments, using it before the function’s body gets execute and returns the compiler back. When the function ends, the passed closure goes out of scope and have no more existence in memory.
 Here is the lifecycle of the @nonescaping closure: 1. Pass the closure in the function argument, during calling the function. 2. Do some additional work in function. 3. Function runs the closure. 4. Function returns the compiler back.*/
func getSumOf1(array:[Int], handler: ((Int)->Void)) {
    //step 2
    var sum: Int = 0
    for value in array {
        sum += value
    }
    
    //step 3
    handler(sum)
}

func doSomething1() {
    //setp 1
    getSumOf1(array: [16,756,442,6,23]) { (sum) in
        print(sum)
        //step 4, finishing the execution
    }
}
//It will print the sumof all the passed numbers.


/*A closure is said to escape a function when the closure is passed as an argument to the function, but is called after the function returns. When you declare a function that takes a closure as one of its parameters, you can write @escaping before the parameter’s type to indicate that the closure is allowed to escape.

One way that a closure can escape is by being stored in a variable that is defined outside the function. As an example, many functions that start an asynchronous operation take a closure argument as a completion handler. The function returns after it starts the operation, but the closure isn’t called until the operation is completed—the closure needs to escape, to be called later. For example: */
//Here is the lifecycle of the @escaping closure: 1. Pass the closure in the function argument, during calling the function. 2. Do some additional work in function. 3. Function runs the closure asynchronously or stored. 4. Function returns the compiler back.
//Example 1 (Storage) :

var complitionHandler: ((Int)->Void)?
func getSumOf(array:[Int], handler: @escaping ((Int)->Void)) {
    //step 2
    var sum: Int = 0
    for value in array {
        sum += value
    }
    //step 3
    complitionHandler = handler
}

func doSomething() {
    //setp 1
    getSumOf(array: [16,756,442,6,23]) { (sum) in
        print(sum)
        //step 4, finishing the execution
    }
}

/*Common use cases for this are:
Asynchronous calls; networking.
Functions stored as variables; think actions and supplied callbacks.
Scheduling tasks on a dispatch queue.*/
/*The main things to watch out for when using closures are:
Assigning a closure to a property of a class instance wherein the body of that closure captures the instance.
Assigning a free-form closure to a property — essentially the same as above but the interaction is between a closure and an instance instead of two instances.*/
//Simple Example of Case 1:


class human
{
    var firstName:String
    var lastName:String
    lazy var fullName:()->String =
        {
            return "\(self.firstName)\(self.lastName)"
            
    }
    
    //To fix
    /*lazy var fullName:() -> String = { [weak self] in
        guard let weakSelf = self else { return “”}
        return “\(weakSelf.firstName) \(weakSelf.lastName)”
     
     
     or
     lazy var fullName:() -> String = { [unowned self] in
     return “\(self.firstName) \(self.lastName)”
     }
    }*/

    init(firstName:String,lastName:String) {
        self.firstName=firstName
        self.lastName=lastName
    }
    deinit {
        print("Human class deinialized")
    }
    
}
var humanObj:human?=human(firstName: "Rajkanya", lastName: "Patel")
humanObj = nil

var humaObj1:human?=human(firstName: "Niraj", lastName: "Pandye")
let fullName=humaObj1?.fullName
humaObj1=nil








class Child {
    func doTheThing(closure: @escaping () -> Void) {
        DispatchQueue.main.async {
            closure()
        }
    }
    deinit {
        print("Child deinit")
    }
}
class Parent {
    var child = Child()
    var name = "Ronny"
    
    func doStuff() {
        child.doTheThing {
            self.name = "Steven"
        }
    }
    deinit {
        print("Parent deinit")
    }
}
//In the above case, parent owns a reference to child, whose closure owns a reference to parent through the use of self. Even if child were optional and its value was assigned to nil, it would not free up that memory due to the reference cycle.
//Consider this class:

class A {
    var closure: (() -> Void)?
    func someMethod(closure: @escaping () -> Void) {
        self.closure = closure
    }
}
//someMethod assigns the closure passed in, to a property in the class.

//Now here comes another class:

class B {
    var number = 0
    var a: A = A()
    func anotherMethod() {
        a.someMethod { self.number = 10 }
    }
}
//If I call anotherMethod, the closure { self.number = 10 } will be stored in the instance of A. Since self is captured in the closure, the instance of A will also hold a strong reference to it.

//That's basically an example of an escaped closure!

//You are probably wondering, "what? So where did the closure escaped from, and to?"

//The closure escapes from the scope of the method, to the scope of the class. And it can be called later, even on another thread! This could cause problems if not handled properly.

//To avoid accidentally escaping closures and causing retain cycles and other problems, use the @noescape attribute:

//class A {
//    var closure: (() -> Void)?
 //   func someMethod(@noescape closure: () -> Void) {
 //   }
//}
//Now if you try to write self.closure = closure, it doesn't compile!

//Update:

//In Swift 3, all closure parameters cannot escape by default. You must add the @escaping attribute in order to make the closure be able to escape from the current scope. This adds a lot more safety to your code!

//class A {
//var closure: (() -> Void)?
//func someMethod(closure: @escaping () -> Void) {
//}
//}

//Auto closures
//Consider a function that takes one argument, a simple closure that takes no argument:

func f(pred: () -> Bool) {
    if pred() {
        print("It's true")
    }
}
//To call this function, we have to pass in a closure

f(pred: {2 > 1})
// "It's true"
//If we omit the braces, we are passing in an expression and that's an error:


//f(pred: 2 > 1)--remove comment and try
// error: '>' produces 'Bool', not the expected contextual result type '() -> Bool'
//@autoclosure creates an automatic closure around the expression. So when the caller writes an expression like 2 > 1, it's automatically wrapped into a closure to become {2 > 1} before it is passed to f. So if we apply this to the function f:

func f(pred: @autoclosure () -> Bool) {
    if pred() {
        print("It's true")
    }
}

f(pred: 2 > 1)
// It's true


//weak vs unnowned
//Both weak and unowned references do not create a strong hold on the referred object (a.k.a. they don't increase the retain count in order to prevent ARC from deallocating the referred object).



//A weak reference allows the posibility of it to become nil (this happens automatically when the referenced object is deallocated), therefore the type of your property must be optional - so you, as a programmer, are obligated to check it before you use it (basically the compiler forces you, as much as it can, to write safe code).

//An unowned reference presumes that it will never become nil during it's lifetime. A unowned reference must be set during initialization - this means that the reference will be defined as a non-optional type that can be used safely without checks. If somehow the object being referred is deallocated, then the app will crash when the unowned reference will be use

class Customer {
    let name: String
    var card: CreditCard?
    init(name: String) {
        self.name = name
    }
    deinit { print("\(name) is being deinitialized") }
}

class CreditCard {
    let number: UInt64
    //remove unowned
   unowned  let customer: Customer
    init(number: UInt64, customer: Customer) {
        self.number = number
        self.customer = customer
    }
    deinit { print("Card #\(number) is being deinitialized") }
}


var john: Customer?
john = Customer(name: "John Appleseed")
john!.card = CreditCard(number: 1234_5678_9012_3456, customer: john!)
john=nil


//delegates - How can I make a weak protocol reference in 'pure' Swift ...
//This code gives a compile error (weak cannot be applied to non-class type MyClassDelegate):

class MyClass {
    //weak var delegate: MyClassDelegate?//-remove comment and check
}

protocol MyClassDelegate {
}
//I need to prefix the protocol with @objc, then it works.


//You need to declare the type of the protocol as class.

protocol ProtocolNameDelegate: class {
    // Protocol stuff goes here
}

class SomeClass {
    weak var delegate: ProtocolNameDelegate?
}

//Delegation pattern
//Table views are a fine example of the delegation pattern. A table view isn't responsible for handling user interaction. It delegates this responsibility to a delegate object, an object that conforms to the UITableViewDelegate protocol. A table view notifies its delegate when the user taps a row in the table view. The result is that table views are highly reusable.
//A table view is usually owned by a view controller. This means that the view controller keeps a strong reference to the table view. It's also possible that the table view is owned by its superview, but let's assume the view controller owns the table view. The table view isn't deallocated as long as the view controller is alive because the view controller holds a strong reference to the table view.
//https://cocoacasts.s3.amazonaws.com/understanding-swift-memory-management/2-what-are-strong-reference-cycles/figure-strong-reference-cycle-1.jpg

//To avoid reference cycle make table view delegate weak

//https://cocoacasts.s3.amazonaws.com/understanding-swift-memory-management/3-how-to-break-a-strong-reference-cycle/figure-break-strong-reference-cycle-1.jpg


